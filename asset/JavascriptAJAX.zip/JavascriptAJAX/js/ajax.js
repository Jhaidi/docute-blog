function InitAjax() {
  var ajax;

  if (window.XMLHttpRequest) {
    ajax = new XMLHttpRequest()
    return ajax
  } else {
    ajax = new ActiveXObject("Msxml2.XMLHTTP")
    return ajax
  }
}

function DoAjaxGet(ajax, url, func_succ) {
  ajax.open("GET", url, true);
  ajax.onreadystatechange = function () {
    if (ajax.readyState == 4 && ajax.status == 200) {
      func_succ(ajax.responseText);
    } else {
      //alert("ajax faild readyState:"+ajax.readyState+" status:"+ajax.status);
    }
  };
  ajax.send(null);
}

function DoAjaxPost(ajax, url, func_succ, post_datas) {
  ajax.open("POST", url, true);
  ajax.onreadystatechange = function () {
    if (ajax.readyState == 4 && ajax.status == 200) {
      func_succ(ajax.responseText);
    } else {
      alert('ajax faild readyState:' + ajax.readyState + " status:" + ajax.status);
    }
  };
  ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
  ajax.send(post_datas);
}